package com.ifa.githubuser

interface ItemClickListener {
    fun onItemClick(data: User)
}